<?php
/**
 * @copyright ©2018 云上科技
 * Created by IntelliJ IDEA
 * Date Time: 2018/7/4 12:06
 */


namespace app\models\tplmsg;

class TplmsgException extends \Exception
{

}
